

<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('main'); ?>


<div class="fudiku-profile-blank-area">
    <div class="container-lg">
        <div class="profile-blank-content">
            <div class="profile-blank-img">
              <img src="<?php echo e(asset('img/vector/profile.png')); ?>" alt="">
            </div>
            <div class="profile-blank-title">
              <h5 class="title">Silahkan Login Terlebih dahulu</h5>
            </div>
            <div class="profile-blank-cta">
              <a href="<?php echo e(route('login')); ?>" class="btn login">Masuk</a>
            </div>
        </div>
    </div>
</div>

<div class="mobile-bottom-nav fixed-bottom">
  <nav class="navbar navbar-expand-lg">
    <div class="container-lg">
      <ul class="navbar-nav">
        <li class="nav-item">
            <a href="<?php echo e(route('profile')); ?>" class="nav-link"><i class="flaticon-user"></i></a>
            Profile
        </li>
        <li class="nav-item active">
            <a href="<?php echo e(route('home')); ?>" class="nav-link"><i class="flaticon-house"></i></a>
            Home
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('cart')); ?>" class="nav-link"><i class="flaticon-shopping-bag"></i></a>
            Cart
        </li>
      </ul>
    </div>
  </nav>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/profile/notLogin.blade.php ENDPATH**/ ?>