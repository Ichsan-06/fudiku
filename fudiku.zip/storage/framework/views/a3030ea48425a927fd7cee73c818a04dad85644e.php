

<?php $__env->startSection('title','Payment Detail'); ?>

<?php $__env->startSection('main'); ?>

<div class="fudiku-payment-detail-area">
    <div class="container-lg">
        <div class="detail-content">
            <div class="row">
                <div class="col-md-12">
                    <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <div class="detail-information">
                        <div class="detail-info">
                            <h6 class="info-head"><strong>Batas Akhir Pembayaran</strong></h6>
                            <?php
                                use carbon\carbon;
                                $tgl = $table->created_at;
                                $date = Carbon::parse("$tgl")->addHour(24);
                            ?>
                            <small><?php echo e(date('j F, Y',strtotime($date) )); ?></small>
                        </div>
                        <div class="detail-info">
                            <h6><strong>Tranfer Via</strong></h6>
                            
                            <img src="<?php echo e(asset("img/payment/$table->image")); ?>" width="80" alt="">
                        </div>
                        <div class="detail-info">
                            <h6 class="info-head"><strong>Nomor Rekening</strong></h6>
                            <small><?php echo e($table->no_rekening); ?></small>
                            <small>A/N <?php echo e($table->name_rekening); ?></small>
                        </div>
                        <div class="total-info">
                            <p class="info-head"><strong>Total Pembayaran</strong></p>
                            <small>Rp. <?php echo e(getPrice($db_order->price)); ?></small>
                        </div>
                        <a href="<?php echo e(url("payment/update/$code")); ?>" class="btn btn-update">Ubah Metode</a>
                        
                    </div>
                    
                    
                </div>
                <div class="col-md-8">
                    <form action="<?php echo e(route('postDetailPayment')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="code" value="<?php echo e($db_order->code_order); ?>">
                        <div class="detail-form">
                            <div class="detail-title">
                                <h6><strong>Konfirmasi Pembayaran</strong></h6>
                            </div>
                            <div class="form-group">
                                <label for=""><small>Nomor Rekening</small></label>
                                <input type="number" min="0" class="form-control" name="no_rekening" required>
                                </div>
                                <div class="form-group">
                                    <label for=""><small>Atas Nama</small></label>
                                    <input type="text" class="form-control" name="name_rekening" required>
                            </div>
                            <div class="">
                                <label for=""><small>Upload Bukti Pembayaran</small></label>
                                <input type="file" class=""  name="image">
                            </div>
                        </div>
                        <div class="detail-cta">
                            
                            <input type="hidden" name="code" value="<?php echo e($code); ?>">
                            
                            <input type="hidden" name="email" value="<?php echo e($db_order->email); ?>">
                            <button type="submit" class="btn next">Konfirmasi Pembayaran</button>
                         </div> 
                    </form>
                </div>
            </div>
            
        </div>
        
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\resources\views/payment/detail.blade.php ENDPATH**/ ?>