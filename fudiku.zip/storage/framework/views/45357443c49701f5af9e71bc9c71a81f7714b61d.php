<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?> </title>
    <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.css')); ?> ">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/icofont.css')); ?> ">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/slick.css')); ?> ">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/slick-theme.css')); ?> ">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/login.css')); ?> ">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

<script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.4.1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/slick.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/login.js')); ?>"></script>
</body>
</html>	<?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\resources\views/template/login.blade.php ENDPATH**/ ?>