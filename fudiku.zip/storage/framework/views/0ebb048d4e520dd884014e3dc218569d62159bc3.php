<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>