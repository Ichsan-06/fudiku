

<?php $__env->startSection('title','Admin'); ?>

<?php $__env->startSection('main'); ?>

<?php $__env->startSection('main-heading'); ?>
    <div class="breadcrumb-area">
        <div class="breadcrumb">
            <li class="breadcrumb-item">Dashboard</li>
            <li class="breadcrumb-item active">Admin</li>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
    
<div class="table-area">
    <div class="table-header">
    </div>
    <div class="table-body">
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Username</th>
                    <th scope="col">Email</th>
                    <th scope="col">Roles</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                        <td scope="row"><?php echo e($data->username); ?></td>                                    
                        <td scope="row"><?php echo e($data->email); ?></td>
                        <td scope="row"><?php echo e(($data->hasrole('admin') == 1) ? 'Admin' : ''); ?></td>
                        <td>    
                            <a href='<?php echo e(url("admin/deleteProduct/$data->id")); ?>' class="btn btn-danger btn-sm">Delete</a>
                            <a href='<?php echo e(url("admin/updateProduct/$data->id")); ?>' class="btn btn-info btn-sm">Update</a>
                            <a href='<?php echo e(url("admin/updateProduct/$data->id")); ?>' class="btn btn-success btn-sm">See Profile</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/admin/admin/index.blade.php ENDPATH**/ ?>