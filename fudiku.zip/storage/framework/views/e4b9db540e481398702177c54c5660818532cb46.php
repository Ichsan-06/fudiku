

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>

<?php $__env->startSection('main'); ?>

<div class="fudiku-cod-area">
    <div class="container-lg">
        <div class="cod-content">
            <form action="">
                <div class="cod-img">
                    <img src="<?php echo e(asset('img/vector/cs.png')); ?>" alt="">
                </div>
                <div class="cod-title">
                    <h5 class="title">Tunggu Customer Kami Menghubungi Anda</h5>
                </div>
                <div class="cod-cta">
                    <!-- <a href="<?php echo e(url("/")); ?>" class="btn btn-update">Kembali Ke Home</a> -->
                    <br>
                    
                </div>
            </form>
        </div>
    </div>
</div>

<div class="mobile-bottom-nav">
  <nav class="navbar navbar-expand-lg">
    <div class="container-lg">
      <ul class="navbar-nav">
        <li class="nav-item">
            <a href="<?php echo e(route('profile')); ?>" class="nav-link"><i class="flaticon-user"></i></a>
            Profile
        </li>
        <li class="nav-item active">
            <a href="<?php echo e(route('home')); ?>" class="nav-link"><i class="flaticon-house"></i></a>
            Home
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('cart')); ?>" class="nav-link"><i class="flaticon-shopping-bag"></i></a>
            Cart
        </li>
      </ul>
    </div>
  </nav>
</div>



<style>
@media(min-width: 576px){
    
    
}    
@media(max-width: 576px){
    
    
}    



</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\resources\views/payment/cod.blade.php ENDPATH**/ ?>