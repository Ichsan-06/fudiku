
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/dataTables.bootstrap4.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/icofont.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/nice-select.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/admin.css')); ?>">
  

</head>
<body>
<div class="main-wrapper">
  <div class="sidebar-wrapper sticky-top">
    <div class="sidebar-logo">
      <a href="<?php echo e(url('/admin')); ?>" class="navbar-brand"><img src="<?php echo e(asset('img/logo/fudiku.png')); ?>" alt=""></a> 
    </div>
    <div class="sidebar-profile">
      <div class="profile-img">
        <img src="<?php echo e(asset('img/profile/admin.jpeg')); ?>" class="rounded-circle" width="50" height="50">
      </div>
      <div class="profile-info">
        <h6 class="username">Ridho Adha</h6>
        <h6 class="level">Admin</h6>
      </div>
    </div>
    <div class="sidebar-menu">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard')); ?> " class="nav-link <?php echo e(request()->path() == 'admin' || request()->path() == 'admin' ? 'active' : ''); ?>"><i class="icofont-pie-chart"></i> Dashboard</a>
        </li>
        
        
        <li class="nav-item" data-toggle="collapse" href="#user" role="button" aria-expanded="false" aria-controls="user">
          <a class="nav-link">User <span class="float-right"><i class="icofont-rounded-right"></i></span></a>
          <li class="nav-item collapse" id="user">
            <a href="<?php echo e(route('customer')); ?>" class="nav-link <?php echo e(request()->path() == 'admin/customer' || request()->path() == 'admin/customer' ? 'active' : ''); ?>">Customer</a>
            <a href="<?php echo e(route('admin')); ?>" class="nav-link <?php echo e(request()->path() == 'admin/admin' || request()->path() == 'admin/administrator' ? 'active' : ''); ?>">Admin</a>
          </li>
        </li>
        <li class="nav-item <?php echo e(request()->path() == 'admin/product' ? 'active' : ''); ?>" data-toggle="collapse" href="#product" role="button" aria-expanded="false" aria-controls="product">
          <a href="<?php echo e(route('product')); ?>" class="nav-link">Product </a>
          
        </li>
        <li class="nav-item <?php echo e(request()->path() == 'admin/subscription' ? 'active' : ''); ?>" data-toggle="collapse" href="#subscription" role="button" aria-expanded="false" aria-controls="subscription">
          <a href="<?php echo e(route('subscription')); ?>" class="nav-link">Subscription </a>
          
        </li>
        
        <li class="nav-item" data-toggle="collapse" href="#category" role="button" aria-expanded="false" aria-controls="category">
          <a class="nav-link">Category <span class="float-right"><i class="icofont-rounded-right"></i></span></a>
          <li class="nav-item collapse" id="category">
            <a href="<?php echo e(route('category')); ?>" class="nav-link">Category</a>
            <a href="<?php echo e(route('SubCategory')); ?>" class="nav-link">Sub Category</a>
          </li>
        </li>
        <li class="nav-item <?php echo e(request()->path() == 'admin/map' ? 'active' : ''); ?>">
          <a href="<?php echo e(route('map')); ?>" class="nav-link"> Map</a>
        </li>
        <li class="nav-item <?php echo e(request()->path() == 'admin/transfer' ? 'active' : ''); ?>">
          <a href="<?php echo e(route('transfer')); ?>" class="nav-link"> Transfer </a>
        </li>
        <li class="nav-item <?php echo e(request()->path() == 'admin/ordering' ? 'active' : ''); ?>">
          <a href="<?php echo e(route('ordering')); ?>" class="nav-link"> Ordering </a>
        </li>
        </ul>
    </div>
  </div>
  <div class="main-content">
    <div class="main-nav">
      <nav class="navbar navbar-expand-md">
        <button class="btn toggle" id="menu-toggle"><i class="icofont-navigation-menu"></i></button>
        <form method="GET" action="" class="navbar-search">
          <div class="form-search">
            <input type="text" class="form-control" placeholder="Cari" name="">
            <button class="btn"><i class="icofont-search-1"></i></button>
          </div>
        </form>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="" class="nav-link"><i class="icofont-email"></i></a></li>
            <li class="nav-item"><a href="" class="nav-link"><i class="icofont-alarm"></i></a></li>
            <li class="nav-item dropdown">
              <a href="" class="nav-link" data-toggle="dropdown"><i class="icofont-user"></i></a>
              <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href=""
                    onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
                </form> 
              </div>
            </li>
          </ul> 
      </nav>    
    
    <div class="main-heading">
      <?php echo $__env->yieldContent('main-heading'); ?>
    </div>      
    <div class="main-body">
      <?php echo $__env->yieldContent('main'); ?>
    </div>
  </div>

</div>
</body>  
</html>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.4.1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.nice-select.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/admin.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/template/admin.blade.php ENDPATH**/ ?>