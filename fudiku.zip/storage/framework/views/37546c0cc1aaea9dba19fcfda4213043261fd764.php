

<?php $__env->startSection('title','Admin - Edit Transfer'); ?>

<?php $__env->startSection('main'); ?>

<?php $__env->startSection('main-heading'); ?>
    <div class="breadcrumb-area">
        <div class="breadcrumb">
            <li class="breadcrumb-item">Dashboard</li>
            <li class="breadcrumb-item active">Edit Transfer</li>
        </div>
    </div>
<?php $__env->stopSection(); ?>  
    
<div class="update-form-area">
    <form action="<?php echo e(url('admin/postUpdateTransfer')); ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" id='id' value="<?php echo e($transfer->id); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Name</label>
            <input type="text" name="name" id='name' class="form-control" placeholder=""  value="<?php echo e($transfer->name); ?>">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Nomor Rekening</label>
            <input type="text" name="no_rekening" id="no_rekening" class="form-control" placeholder="" value="<?php echo e($transfer->no_rekening); ?>">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Atas Nama</label>
            <input type="text" name="name_rekening" id="atas_nama" class="form-control" placeholder="" value="<?php echo e($transfer->name_rekening); ?>">
        </div>
        <div class="form-group">
            <label >Logo</label><br>
            <input type="file" name="logo" id="logo" class="form-control">
            <small>*isi jika mau diupdate</small>
        </div>
        <!-- <div class="modal-body">
            
        </div>
        
        <div class="modal-footer">
            <a href="<?php echo e(url('admin/transfer')); ?>"  class="btn btn-danger" data-dismiss="modal">Kembali</a>
            <button type="submit" class="btn btn-primary">Tambah</button>
        </div> -->
    </form>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/admin/transfer/update.blade.php ENDPATH**/ ?>