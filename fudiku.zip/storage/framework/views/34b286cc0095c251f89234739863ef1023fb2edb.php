

<?php $__env->startSection('title','Admin'); ?>

<?php $__env->startSection('main'); ?>

<?php $__env->startSection('main-heading'); ?>

    <div class="breadcrumb-area">
        <div class="breadcrumb">
            <li class="breadcrumb-item">Dashboard</li>
            <li class="breadcrumb-item active">Category</li>
        </div>

    </div>
    <div class="add-area ml-auto">
        <a href="#" class="btn add-btn" data-toggle="modal" data-target="#exampleModal">
            Tambah Data
        </a>
    </div>

<?php $__env->stopSection(); ?>         
    
<div class="table-area">
    <div class="table-header">
        
    </div>
    <div class="table-body">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Slug</th>
                    <th scope="col" width="30%">Description</th>
                    <th scope="col">Is Active</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($loop->index + 1); ?></td>
                        <td scope="row"><?php echo e($data->name); ?></td>                                    
                        <td scope="row"><?php echo e($data->slug); ?></td>                                    
                        <td scope="row" width="30%"><?php echo e($data->desc); ?></td>                                    
                        <form>
                            <?php echo csrf_field(); ?>
                            <td><input type="checkbox" class='checked' data-id="<?php echo e($data->id); ?>"  <?php if($data->isActive == 1): ?>
                                <?php echo e('checked'); ?>

                            <?php endif; ?>></td>
                        </form>
                        <td>
                        <a href='<?php echo e(url("admin/deleteCategory/$data->id")); ?>' class="btn btn-danger btn-sm">Delete</a>
                        
                        <button class="btn updateBtn btn-sm btn-info" data-id="<?php echo e($data->id); ?>">Update</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>    
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Kategori</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?php echo e(route('tambahCategory')); ?>" method="post">
            <div class="modal-body">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" name="name" class="form-control" placeholder="Kategori">
                </div>
                <div class="form-group">
                    <input type="text" name="slug" class="form-control" placeholder="Slug">
                </div>
                <div class="form-group">
                    <input type="text" name="desc" class="form-control" placeholder="Description">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Tambah</button>
            </div>
        </form>
        </div>
    </div>
</div>

<div class="modal fade" id="updateModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editFormKategori" method="POST">
                <input type="hidden" name="id" id='id'>
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" name="name" id="name" class="form-control" placeholder="Kategori">
                    </div>
                    <div class="form-group">
                        <input type="text" name="slug" id="slug" class="form-control" placeholder="Slug">
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $('.updateBtn').click(function(){
                $('.modal-title').text('Update Data')
                $('#updateModal').modal('show');
                
                $tr = $(this).closest('tr');

                var data = $tr.children('td').map(function(){
                    return $(this).text();
                }).get();
                var dataId = $(this).attr('data-id');


                $('#name').val(data[0]);
                $('#slug').val(data[1]);
                $('#desc').val(data[2]);
                $('#id').val(dataId);
            });  
            

            $('.checked').on('change',function(e){
                var dataId = $(this).attr('data-id');
                // console.log(dataId);
                if ($(this).is(":checked"))
                {
                    var isChecked =  1;
                }
                else{
                    var isChecked =  0;
                }
                e.preventDefault();
                $.ajax({
                    type:'POST',
                    url : '/admin/changeIsActive/'+dataId,
                    headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                    data:{ "value" : isChecked },
                    success:function(response){
                        // console.log(response);
                        alert('data berhasil diubah')
                    },
                    error:function(error){
                        alert('data gagal diubah')
                    } 
                });
            })
        });
        
        $('#editFormKategori').on('submit',function(e){
            e.preventDefault();
            var id = $('#id').val();

            $.ajax({
                type:'POST',
                url : '/admin/updateCategory/'+id,
                data:$('#editFormKategori').serialize(),
                success:function(response){
                    console.log(response);
                    $('#updateModal').modal('hide');
                    window.location.reload();
                },
                error:function(error){
                    console.log(error);
                } 
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/admin/category/index.blade.php ENDPATH**/ ?>