

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>

<?php $__env->startSection('main'); ?>
<div class="fudiku-search-area">
    <div class="search-content">
        <form action="<?php echo e(url('/menu/search')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="fudiku-search">
                <div class="form-field">
                    <input type="text" class="form-control" value="<?php echo e($location); ?>" name="location">
                    <button type="submit" class="btn"><i class="icofont-search"></i></button>
                </div>
            </div>
        </form>
        <div class="fudiku-category">
            <ul class="nav">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item <?php echo ($slug == $category->slug ) ? 'active' : '' ?>">
                    <a href="<?php echo e(url("menu/$category->slug/$location")); ?>" class="nav-link"><?php echo e($category->name); ?></a>
                </li>                                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </ul>
        </div>
    </div> 
</div>
<?php if($count == 0): ?>
<div class="fudiku-not-available-area">
    <div class="container-lg">
        <div class="not-available-content">
            <div class="not-available-img">
                <img src="<?php echo e(asset('img/vector/not-available.png')); ?>" alt="">
            </div>
            <div class="not-available-title">
                <h5 class="title">Maaf, layanan belum tersedia di daerahmu.</h5>
            </div>
        </div>
    </div>
</div>    
<?php else: ?>

<div class="fudiku-delivery-area">
    <div class="container-lg">
        <div class="delivery-content">
            <div class="delivery-info">
                <h6><strong>Pengantaran 11.00 - 13.00 WIB</strong></h6>
                <small>Pesananmu akan tiba secepatnya.</small>
            </div>
        </div>
    </div>
</div>


<?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="fudiku-menu-area">
    <div class="container-lg">
        
            <?php echo csrf_field(); ?>
            <input type="hidden" name="location" value="<?php echo e($location); ?>">
                <input type="hidden" name="id" value="<?php echo e($sub->id); ?>">
                <?php
                    $product = App\Product::where('id_sub_category',$sub->id)
                    ->where( 'date_delivery', '>', \Carbon\Carbon::now())
                    ->orderBy('date_delivery','ASC')
                    ->limit(15)
                    ->get();                    
                ?>
                <div class="menu-content">
                    <div class="menu-title">
                        <h3 class="title"><?php echo e($sub->name); ?></h3>
                        <p class="subtitle"><?php echo e($sub->information); ?></p>
                    </div>
                    <div class="menu owl-carousel owl-theme">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="menu-item">
                                    
                                    <a href="#" class="updateModal">

                                    <div class="menu-img">
                                        <img src='<?php echo e(asset("img/product/$products->image")); ?>' alt="" class="image">
                                    </div>
                                    <div class="menu-desc">
                                        <span class="dates"><?php echo e($products->date_delivery->isoFormat('dddd, D MMMM Y')); ?></span>
                                        <p class="menu-name"><?php echo e($products->name); ?></p>
                                    </div>
                                    
                                </a>
                                
                            </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>

                    <div class="menu-popup" id="popUpMenu">
                        <div class="modal fade " id="updateModal" tabindex="-1" aria-labelledby="menu-popup" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content menu-popup-content">
                                <div class="modal-header menu-popup-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true"><i class="icofont-close"></i></span>
                                    </button>
                                </div>
                                <div class="menu-popup-img">
                                    <img src="<?php echo e(asset('img/menu/ampela.jpg')); ?>" alt="" id="img">
                                </div>
                                <div class="menu-popup-desc">
                                    <small class="date" id="date"></small>
                                    <p class="info" id="name"></p>
                                </div>
                                <!-- <div class="modal-body menu-popup-item">
                                </div> -->
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="menu-cta">
                        
                        <a href="<?php echo e(url("/order/$location/$sub->id")); ?>" class="btn next">Langganan</a>
                    </div>
                </div>
                
                
                
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
         $(document).ready(function(){
            $('.updateModal').click(function(){
                // $('.modal-title').text('Update Data');
                $('#updateModal').modal('show');
                
                var tr = $(this).parent();
                
                console.log();


                // var date = tr.getElementsByClassName('dates');
                // var name = tr.getElementsByClassName('menu-name');


                // var date = $(this).attr('data-date');
                // var name = $(this).attr('menu-name');

                $('#date').text(tr.find(".dates").text());
                $('#name').text(tr.find(".menu-name").text());
                $('#img').attr("src",tr.find(".image").attr('src'));
                // console.log(tr)
                
            });  
            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\resources\views/menu/byCategory.blade.php ENDPATH**/ ?>