

<?php $__env->startSection('title','Admin'); ?>

<?php $__env->startSection('main'); ?>

<?php $__env->startSection('breadcrumb'); ?>

<div class="breadcrumb">
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Edit Product</li>
</div>

<?php $__env->stopSection(); ?>      
    
<div class="update-form-area">
    <form method="POST" action="<?php echo e(url('admin/storeUpdateProduct')); ?>" enctype="multipart/form-data">
        <div class="form-group">
            <input type="hidden" name="id" value="<?php echo e($tbl_product->id); ?>">
            <label for="exampleInputEmail1">Name</label>
            <?php echo csrf_field(); ?>
            <input type="text" name="name" class="form-control" placeholder="Enter Name" value="<?php echo e(old('name',$tbl_product->name_product)); ?>" required>
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Date Delivery</label>
            <input type="date" name="date_delivery" class="form-control" id="date_delivery" value="<?php echo e(old('date_delivery',$tbl_product->date_delivery->format('Y-m-d'))); ?>" placeholder="Enter date delivery" required>
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Image</label>                        
            <input type="file" name="image" class="form-control" id="image" placeholder="image" >
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Category</label>
            <?php
                $table = DB::table('sub_category')
                            ->where('isActive','1')
                            ->get();
            ?>
            <select name="category" id="category" class="form-control" required>
                <option hidden value="<?php echo e($tbl_product->id_sub_category); ?>"><?php echo e($tbl_product->name); ?></option>
                <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
            <button class="btn btn-info btn-sm">Update</button>
        <a class="btn btn-primary btn-sm" href="<?php echo e(url('/admin/product')); ?>">Back</a>
    </form>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/admin/product/update.blade.php ENDPATH**/ ?>