<?php $__env->startComponent('mail::message'); ?>
Halo <b><?php echo e($data['name']); ?></b>
<h1>Pembayaran berhasil, mohon menunggu
    verifikasi </h1>
Terima kasih! Berikut detail pesananmu,
<br>
<section>
    <Table>
        <tr>
            <td>Total Bayar</td>
            <td>:</td>
            <td style="font-weight:bold;color:red">Rp.<?php echo e($data['jumlah']); ?></td>
        </tr>
        <tr>
            <td>Metode Bayar</td>
            <td>:</td>
            <td><b><?php echo e($data['metode']); ?></b></td>
        </tr>
        <tr>
            <td>Total Bayar</td>
            <td>:</td>
            <td><b><?php echo e($data['paket']); ?></b></td>
        </tr>
        <tr>
            <td>Lama Berlangganan</td>
            <td>:</td>
            <td><b><?php echo e($data['subsName']); ?> -</b> <?php echo e($data['duration']); ?>Hari</td>
        </tr>
    </Table>
</section>

<h1 style="text-align: center;margin-top:30px" >
    Fudiku Gratis Ongkir,
    Bebas Atur Jadwal Sesukamu.</h1>

<p>Beragam menu berkualitas setiap harinya dengan pilihan paket lengkap
    sesuai kebutuhanmu. Atur kapan aja makananmu akan diantar, bisa
    bayar di tempat.</p>


<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Pesan Sekarang
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<img class="slider" src="<?php echo e(asset('img/slider/1.png')); ?>" class="logo" alt="Laravel Logo"><br>
<p>E-mail ini dibuat otomatis, mohon tidak membalas. Jika butuh bantuan,
    silakan hubungi Customer Service Fudiku.</p>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/emails/welcome.blade.php ENDPATH**/ ?>