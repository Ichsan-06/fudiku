<?php echo e($slot); ?>

<?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>