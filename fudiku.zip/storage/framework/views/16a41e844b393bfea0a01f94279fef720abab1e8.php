

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>

<?php $__env->startSection('main'); ?>


<div class="fudiku-form-area">
    <div class="container-lg">
        <div class="form-title">
            <h5 class="title">Lengkapi data dibawah ini</h5>
            <small class="subtitle">Isi form berikut untuk melanjutkan ke pembayaran</small>
        </div>
        <div class="form-content">
            <div class="form-area">
                <form action="<?php echo e(route('postForm')); ?>" method="post" class="form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id_subcategory" value="<?php echo e($id_subcategory); ?>">
                    <input type="hidden" name="id_subscription" value="<?php echo e($id_subscription); ?>">
                    <input type="hidden" name="date_delivery" value="<?php echo e($date_delivery); ?>">
                    <div class="form-group">
                        <!-- <label for="">Nama Lengkap</label> -->
                        <input type="text" class="form-control" placeholder="Nama Lengkap"  name="full_name" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" min="0" placeholder="Nomor WhatsApp" name="phone" id="" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <!-- <label for="">Email</label> -->
                        <input type="email" class="form-control"  placeholder="Email" name="email" autocomplete="off" required value="<?php echo e($email); ?>" <?php if ($email != null) echo "" ?>>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <!-- <option value="">Kabupaten</option> -->
                            <select class="form-control city" name="kabupaten" id="kabupaten" placeholder="Kabupaten" required>
                                <!-- <option value="">Pilih Kabupaten</option> -->
                                <?php $__currentLoopData = $table_map; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kabupaten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kabupaten->kabupaten); ?>" <?php if ($location == $kabupaten->kabupaten)echo  "selected" ?>><?php echo e($kabupaten->kabupaten); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </div>
                        <div class="form-group col-md-6">
                            <select class="form-control kecamatan disabled" name="kecamatan" id="kecamatan" required>
                                
                                <option value="<?php echo e($kecamatan); ?>"><?php echo e($kecamatan); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <!-- <label for="">Alamat</label> -->
                        <textarea name="address" class="form-control" id="" cols="30" rows="10" placeholder="Alamat" autocomplete="off" required></textarea>
                    </div>
                    
                    <button class="btn next">Lanjutkan</button>
                    
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('#kabupaten').on('change',function () {
                var kabupaten = $(this).val();
                $.ajax({
                    url: "/formLocation",
                    headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                    type : 'POST',
                    data:{
                        kabupaten : kabupaten
                    },
                    success:function(respond) {
                        $('.kecamatan').html(respond);
                        console.log(respond);
                    },
                    error:function(){
                        alert('Gagal');
                    }
                })
            })
            
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/form/index.blade.php ENDPATH**/ ?>