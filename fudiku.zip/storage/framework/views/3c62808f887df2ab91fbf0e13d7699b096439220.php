

<?php $__env->startSection('title','Edit Profile'); ?>

<?php $__env->startSection('main'); ?>

<div class="fudiku-profile-edit-area">
    <div class="container-lg">
        <div class="profile-edit-content">
            <form action="" class="profile-edit-form">
                <div class="profile-edit-img">
                    <!-- <img src="" alt=""> -->
                    <div class="dropzone">
                        <div class="fallback">
                            <input type="file">
                        </div>
                    </div>
                    <!-- <label for="upload"><i class="icofont-camera"></i></label> -->
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Username">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Email">
                </div>
                <button class="btn">Simpan</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/profile/edit.blade.php ENDPATH**/ ?>