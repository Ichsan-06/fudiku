

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>

<?php $__env->startSection('main'); ?>



<div class="fudiku-payment-area">
    <div class="container-lg">
        <div class="payment-title">
            <h5 class="title">Pilih Metode Pembayaran</h5>
        </div>
        <div class="payment-content">
            <form action="<?php echo e(route('payment.post')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="payment-method">
                            <div class="payment">
                                <input type="radio" name="payment" id="<?php echo e($payment->name); ?>" value="<?php echo e($payment->name); ?>">
                                <label  for="<?php echo e($payment->name); ?>">
                                    <input type="hidden" name="code" value="<?php echo e($code); ?>">
                                    <div class="payment-logo">
                                            <img src="<?php echo e(asset("img/payment/$payment->image")); ?>" alt="">
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <div class="payment-cta">
                    
                    <button class="btn next">Lanjutkan</button>    
                </div>
            </form>
        </div>    
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\resources\views/payment/index.blade.php ENDPATH**/ ?>