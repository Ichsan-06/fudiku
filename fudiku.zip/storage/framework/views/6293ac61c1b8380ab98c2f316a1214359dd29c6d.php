

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>

<?php $__env->startSection('main'); ?>



<div class="fudiku-order-area">
    <div class="container-lg">
        <div class="order-content">
            <form action="<?php echo e(route('schedule')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="order-menu">
                            <div class="menu-title">
                                <h3 class="title"><?php echo e($subCategory->name); ?></h3>
                                <span class="subtitle"><?php echo e($subCategory->information); ?></span>
                            </div>
                            <div class="order-menu-item owl-carousel owl-theme">
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="menu-item">
                                        <a href="#" class="updateModal">
                                            <div class="menu-img">
                                                <img class="image" src='<?php echo e(asset("img/product/$products->image")); ?>' alt="">
                                            </div>
                                            <div class="menu-desc">
                                                <span class="date"><?php echo e($products->date_delivery->isoFormat('dddd, D MMMM Y')); ?></span>
                                                <p class="menu-name"><?php echo e($products->name); ?></p>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="menu-popup" id="popUpMenu">
                                <div class="modal fade " id="updateModal" tabindex="-1" aria-labelledby="menu-popup" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content menu-popup-content">
                                        <div class="modal-header menu-popup-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true"><i class="icofont-close"></i></span>
                                            </button>
                                        </div>
                                        <div class="menu-popup-img">
                                            <img src="<?php echo e(asset('img/menu/ampela.jpg')); ?>" alt="" id="img">
                                        </div>
                                        <div class="menu-popup-desc">
                                            <small class="date" id="date"></small>
                                            <p class="info" id="name"></p>
                                        </div>
                                        <!-- <div class="modal-body menu-popup-item">
                                        </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="order-packet">
                            <div class="packet-title">
                                <h3 class="title">Pilih paket anda</h3>
                                
                            </div>
                            <div class="packet-option">
                                <?php $__currentLoopData = $subscription; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="packet">
                                    <input type="radio" name="subscription" id="<?php echo e($data_sub->id); ?>"  value ="<?php echo e($data_sub->id); ?>">
                                    <label class="label" for="<?php echo e($data_sub->id); ?>">
                                        <input type="hidden" name="id_subcategory" value="<?php echo e($id_subcategory); ?>">
                                        <div class="packet-info">
                                            <input type="hidden" name="id_subcategory" value="<?php echo e($id_subcategory); ?>">
                                            <p class="name"><?php echo e($data_sub->name); ?></p>
                                            <span class="day"><?php echo e($data_sub->duration); ?> Hari </span>
                                        </div>
                                        <div class="packet-price">
                                            <?php if($data_sub->discount !== null): ?>
                                                <p class="tax">Hemat <?php echo e($data_sub->discount); ?>%</p>
                                            <?php endif; ?>
                                            <?php
                                                // $discount = $data_su
                                            ?>
                                            <span class="price">Rp. <?php echo e(getPrice($data_sub->price)); ?></span>
                                        </div>
                                    </label>
                                 </div>   
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>  
                            
                        <!-- <?php $__currentLoopData = $subscription; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="radio" name="subscription" id="" value="<?php echo e($data_sub->id); ?>" checked>
                            <input type="hidden" name="id_subcategory" value="<?php echo e($id_subcategory); ?>">
                            <label>
                                Paket
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                            <!-- <div class="packet-info">
                                <p><strong class="name"><?php echo e($data_sub->name); ?></strong></p>
                                <span class="day"><?php echo e($data_sub->duration); ?> Hari </span>
                            </div>
                            <div class="packet-price">
                                <?php if($data_sub->discount !== null): ?>
                                    <p><strong class="tax">Hemat <?php echo e($data_sub->discount); ?>%</strong></p>
                                <?php endif; ?>
                                <?php
                                    // $discount = $data_su
                                ?>
                                <span class="price">Rp. <?php echo e(getPrice($data_sub->price)); ?></span>
                            </div> -->
                        </div>
                        <div class="order-cta">
                            <input type="hidden" name="location" value="<?php echo e($location); ?>">
                            <button type="submit" class="btn next">Atur Tanggal</button>
                        </div>
                    </div>
                </div>
            </form>                
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
         $(document).ready(function(){
            $('.updateModal').click(function(){
                // $('.modal-title').text('Update Data');
                $('#updateModal').modal('show');
                
                var tr = $(this).parent();
                
                console.log();


                // var date = tr.getElementsByClassName('dates');
                // var name = tr.getElementsByClassName('menu-name');


                // var date = $(this).attr('data-date');
                // var name = $(this).attr('menu-name');

                $('#date').text(tr.find(".date").text());
                $('#name').text(tr.find(".menu-name").text());
                $('#img').attr("src",tr.find(".image").attr('src'));
                // console.log(tr)
                
            });  
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/order/index.blade.php ENDPATH**/ ?>