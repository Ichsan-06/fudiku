

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>   

<?php $__env->startSection('main'); ?>

<div class="fudiku-location-area">
    <div class="location-content">
        <div class="location-form"> 
            <form action="<?php echo e(route('postLocation')); ?>" class="form" method="POST">
                <?php echo csrf_field(); ?>
                <div class="location-title">
                    <h4 class="title">Pilih Lokasimu</h4>
                </div>
                <div class="form-field">
                    <input type="text" id="location" required list="list-city" autocomplete="off" name="location" tabindex="1" class="location form-control" placeholder="Cari Kabupaten Kamu">
                    <button type="submit" class="btn"><i class="icofont-search"></i></button>
                    
                    
                    <div class="location-search-area"></div>
                </div>
            </form>
        </div>
        <div class="location-img-area">
            <div class="location-slider owl-carousel">
                <?php for($i = 0; $i < 4; $i++): ?>
                <div class="location-item">
                    <div class="location-img">
                        <img src="<?php echo e(asset('img/vector/map.png')); ?>" alt="">
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>
    
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('.location').keyup(function() {
                var query = $(this).val();

                if (query !== null) {
                    $.ajax({
                        url:'/searchLocation',
                        method:'POST',
                        headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                        data:{query:query},
                        success:function(data){
                            $('.location-search-area').fadeIn();
                            $('.location-search-area').html(data);
                        }
                    })
                }
                else{
                    $('.location-search-area').fadeOut();
                }
    
            })
            $(document).on('click','a',function() {
                $('.location-search-area').fadeOut();
                $('.location').val($(this).text());
            })
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\laravel\fudikugit\fudiku\resources\views/location/index.blade.php ENDPATH**/ ?>