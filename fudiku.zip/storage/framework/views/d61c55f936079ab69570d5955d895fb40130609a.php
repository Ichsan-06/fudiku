

<?php $__env->startSection('title','Finish'); ?>

<?php $__env->startSection('main'); ?>

<div class="fudiku-finish-area">
    <div class="container-lg">
        <div class="finish-content">
            <div class="finish-img">
                <img src="<?php echo e(asset('img/vector/cs.png')); ?>" alt="">
            </div>
            <div class="finish-title">
                <h5 class="title">Tunggu Cutomer Service kami menghubungimu</h5>
            </div>
        </div>
    </div>
</div>

<div class="mobile-bottom-nav fixed-bottom">
  <nav class="navbar navbar-expand-lg">
    <div class="container-lg">
      <ul class="navbar-nav">
        <li class="nav-item">
            <a href="<?php echo e(route('profile')); ?>" class="nav-link"><i class="flaticon-user"></i></a>
            Profile
        </li>
        <li class="nav-item active">
            <a href="<?php echo e(route('home')); ?>" class="nav-link"><i class="flaticon-house"></i></a>
            Home
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('cart')); ?>" class="nav-link"><i class="flaticon-shopping-bag"></i></a>
            Cart
        </li>
      </ul>
    </div>
  </nav>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/finish/index.blade.php ENDPATH**/ ?>