

<?php $__env->startSection('title','Fudiku - Cara Baru Pesan Catering'); ?>

<?php $__env->startSection('main'); ?>

<div class="fudiku-about-area">
    <div class="container-lg">
        <div class="about-content">
            <h6>Tentang</h6>
            <!-- <hr> -->
            <p>Fudiku adalah layanan catering online berlangganan yang memberdayakan dapur UMKM rumahan sebagai kitchen-partner. 
            Dimasak dengan sepenuh hati dan cinta.</p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/about/index.blade.php ENDPATH**/ ?>