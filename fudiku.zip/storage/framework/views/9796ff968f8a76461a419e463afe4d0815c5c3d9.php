

<?php $__env->startSection('title','About'); ?>

<?php $__env->startSection('main'); ?>

<div class="fudiku-about-area">
    <div class="container-lg">
        <div class="about-content">
            <h5>Tentang</h5>
            <p>Fudiku adalah layanan catering online berlangganan yang memberdayakan dapur UMKM rumahan sebagai kitchen-partner. Dimasak dengan sepenuh hati dan cinta.</p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/about/index.blade.php ENDPATH**/ ?>