

<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('main'); ?>


<div class="fudiku-profile-area">
    <div class="container-lg">
        <div class="profile-content">
            <div class="profile">
                <div class="profile-img">
                    <img src="<?php echo e(asset('img/profile/')); ?>" alt="">
                </div>
                <div class="profile-info">
                    <h5 class="name"><?php echo e(Auth::user()->username); ?></h5>
                </div>
                <div class="profile-edit">
                    <form action="<?php echo e(route('profile.edit')); ?>">
                        <button class="btn">Edit Profile</button>
                    </form>
                </div>
                
            </div>
            <div class="profile-detail-info">
                
                
                <div class="detail-info">
                    <h6 class="info-heading">Email</h6>
                    <small><?php echo e(Auth::user()->email); ?></small>
                </div>
                <div class="detail-info">
                    <h6 class="info-heading">Menu Favorit</h6>
                    <small>Chicken Club</small>
                </div>
                
            </div>
            <div class="profile-cta">
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn login "><?php echo e(__('Masuk')); ?></a> 
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn login "><?php echo e(__('Daftar')); ?></a> 
                    <?php endif; ?>

                    <?php else: ?>
                        <a class="btn login" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                
                
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="mobile-bottom-nav fixed-bottom">
  <nav class="navbar navbar-expand-lg">
    <div class="container-lg">
      <ul class="navbar-nav">
        <li class="nav-item">
            <a href="<?php echo e(route('profile')); ?>" class="nav-link"><i class="flaticon-user"></i></a>
            Profile
        </li>
        <li class="nav-item active">
            <a href="<?php echo e(route('home')); ?>" class="nav-link"><i class="flaticon-house"></i></a>
            Home
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('cart')); ?>" class="nav-link"><i class="flaticon-shopping-bag"></i></a>
            Cart
        </li>
      </ul>
    </div>
  </nav>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\laravel\fudikugit\fudiku\resources\views/profile/index.blade.php ENDPATH**/ ?>